﻿using System;
using System.Linq;
using Correspondence.WP7.Model;

namespace $safeprojectname$
{
    public class ConversationViewModel
    {
        private User _user;
        private Conversation _conversation;

        public ConversationViewModel(User user, Conversation conversation)
        {
            _user = user;
            _conversation = conversation;
        }

        public Conversation Conversation
        {
            get { return _conversation; }
        }

        public string OtherUserName
        {
            get
            {
                return (
                    from participant in _conversation.Participants
                    where participant != _user
                    select participant.UserName
                    ).FirstOrDefault();
            }
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            ConversationViewModel that = obj as ConversationViewModel;
            if (that == null)
                return false;
            return _conversation == that._conversation;
        }

        public override int GetHashCode()
        {
            return _conversation.GetHashCode();
        }
    }
}
