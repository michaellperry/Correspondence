﻿using System;
using System.Collections.Generic;
using System.Linq;
using Correspondence.WP7.Model;
using System.Windows.Input;
using UpdateControls.XAML;

namespace $safeprojectname$
{
    public class UserViewModel
    {
        private User _user;
        private UserNavigationModel _navigation;

        public UserViewModel(
            User user,
            UserNavigationModel navigation)
        {
            _user = user;
            _navigation = navigation;
        }

        public string UserName
        {
            get { return _user.UserName; }
        }

        public string OtherUserName
        {
            get { return _navigation.OtherUserName; }
            set { _navigation.OtherUserName = value; }
        }

        public ICommand BeginConversation
        {
            get
            {
                return MakeCommand
                    .When(() => !String.IsNullOrEmpty(_navigation.OtherUserName))
                    .Do(() => _user.BeginConversation(_navigation.OtherUserName));
            }
        }

        public IEnumerable<ConversationViewModel> Conversations
        {
            get
            {
                return
                    from conversation in _user.Conversations
                    select new ConversationViewModel(_user, conversation);
            }
        }

        public ConversationViewModel SelectedConversation
        {
            get
            {
                return _navigation.SelectedConversation != null
                    ? new ConversationViewModel(_user, _navigation.SelectedConversation)
                    : null;
            }
            set
            {
                _navigation.SelectedConversation = value != null
                    ? value.Conversation
                    : null;
            }
        }
    }
}
