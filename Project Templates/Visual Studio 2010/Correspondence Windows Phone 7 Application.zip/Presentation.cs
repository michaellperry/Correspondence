﻿using UpdateControls.XAML;

namespace $safeprojectname$
{
    public class Presentation
    {
        private ViewModelLocator _locator = new ViewModelLocator();

        public object Locator
        {
            get { return ForView.Wrap(_locator); }
        }

    }
}
