﻿using Correspondence.WP7.Model;
using Correspondence.WP7.ViewModel;
using UpdateControls.Correspondence;
using UpdateControls.Correspondence.IsolatedStorage;
using UpdateControls.Correspondence.WebServiceClient;

namespace $safeprojectname$
{
    public class ViewModelLocator
    {
        private User _user;
        private UserViewModel _userViewModel;

        public ViewModelLocator()
        {
            Community community = new Community(IsolatedStorageStorageStrategy.Load())
                .AddAsynchronousCommunicationStrategy(new WebServiceCommunicationStrategy("$safeprojectname$"))
                .RegisterAssembly(typeof(User))
                .Subscribe(() => _user);
            _user = community.AddFact(new User("Bob"));
            _userViewModel = new UserViewModel(_user, new UserNavigationModel());

            _user.BeginConversation("Alice");
            _user.BeginConversation("Charles");
        }

        public UserViewModel UserViewModel
        {
            get { return _userViewModel; }
        }
    }
}
