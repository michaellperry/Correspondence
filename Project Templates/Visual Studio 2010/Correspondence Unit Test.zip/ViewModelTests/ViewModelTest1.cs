﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UpdateControls.Correspondence;
using UpdateControls.Correspondence.Memory;

namespace $safeprojectname$.ViewModelTests
{
	[TestClass]
	public class ViewModelTest1
	{
		private Community _community;
		private ViewModel1 _viewModel;

		[TestInitialize]
		public void Initialize()
		{
			_community = new Community(new MemoryStorageStrategy())
				.RegisterAssembly(typeof(User));
			Machine machine = _community.AddFact(new Machine());
			NavigationModel1 navigation = new NavigationModel1();
			_viewModel = new ViewModel1(machine, navigation);
		}

		[TestMethod]
		public void Test1()
		{
			Assert.Fail();
		}
	}
}
