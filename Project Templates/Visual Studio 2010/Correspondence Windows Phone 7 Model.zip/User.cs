﻿using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public partial class User
    {
        public Conversation BeginConversation(string otherUserName)
        {
            User otherUser = Community.AddFact(new User(otherUserName));
            return Community.AddFact(new Conversation(new List<User> { this, otherUser }));
        }
    }
}
