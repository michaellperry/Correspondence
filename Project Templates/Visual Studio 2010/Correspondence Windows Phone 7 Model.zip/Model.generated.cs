﻿using System.Collections.Generic;
using System.Linq;
using UpdateControls.Correspondence;
using UpdateControls.Correspondence.Mementos;
using System;

/**
// For use with http://graphviz.org/
digraph "$safeprojectname$"
{
    rankdir=BT
    Conversation -> User [label="  *"] [color="red"]
    Message -> Conversation
    Message -> User
}
**/

namespace $safeprojectname$
{
    [CorrespondenceType]
    public partial class User : CorrespondenceFact
    {
        // Roles

        // Queries
        public static Query QueryConversations = new Query()
            .JoinSuccessors(Conversation.RoleParticipants)
            ;

        // Predicates

        // Predecessors

        // Fields
        [CorrespondenceField]
        public string _userName;

        // Results
        private Result<Conversation> _conversations;

        // Business constructor
        public User(
            string userName
            )
        {
            InitializeResults();
            _userName = userName;
        }

        // Hydration constructor
        public User(FactMemento memento)
        {
            InitializeResults();
        }

        // Result initializer
        private void InitializeResults()
        {
            _conversations = new Result<Conversation>(this, QueryConversations);
        }

        // Predecessor access

        // Field access
        public string UserName
        {
            get { return _userName; }
        }

        // Query result access
        public IEnumerable<Conversation> Conversations
        {
            get { return _conversations; }
        }
    }
    
    [CorrespondenceType]
    public partial class Conversation : CorrespondenceFact
    {
        // Roles
        public static Role<User> RoleParticipants = new Role<User>("participants", RoleRelationship.Pivot);

        // Queries
        public static Query QueryMessages = new Query()
            .JoinSuccessors(Message.RoleConversation)
            ;

        // Predicates

        // Predecessors
        private PredecessorList<User> _participants;

        // Fields

        // Results
        private Result<Message> _messages;

        // Business constructor
        public Conversation(
            IEnumerable<User> participants
            )
        {
            InitializeResults();
            _participants = new PredecessorList<User>(this, RoleParticipants, participants);
        }

        // Hydration constructor
        public Conversation(FactMemento memento)
        {
            InitializeResults();
            _participants = new PredecessorList<User>(this, RoleParticipants, memento);
        }

        // Result initializer
        private void InitializeResults()
        {
            _messages = new Result<Message>(this, QueryMessages);
        }

        // Predecessor access
        public IEnumerable<User> Participants
        {
            get { return _participants; }
        }
     
        // Field access

        // Query result access
        public IEnumerable<Message> Messages
        {
            get { return _messages; }
        }
    }
    
    [CorrespondenceType]
    public partial class Message : CorrespondenceFact
    {
        // Roles
        public static Role<Conversation> RoleConversation = new Role<Conversation>("conversation");
        public static Role<User> RoleSender = new Role<User>("sender");

        // Queries

        // Predicates

        // Predecessors
        private PredecessorObj<Conversation> _conversation;
        private PredecessorObj<User> _sender;

        // Fields
        [CorrespondenceField]
        public string _body;

        // Results

        // Business constructor
        public Message(
            Conversation conversation
            ,User sender
            ,string body
            )
        {
            InitializeResults();
            _conversation = new PredecessorObj<Conversation>(this, RoleConversation, conversation);
            _sender = new PredecessorObj<User>(this, RoleSender, sender);
            _body = body;
        }

        // Hydration constructor
        public Message(FactMemento memento)
        {
            InitializeResults();
            _conversation = new PredecessorObj<Conversation>(this, RoleConversation, memento);
            _sender = new PredecessorObj<User>(this, RoleSender, memento);
        }

        // Result initializer
        private void InitializeResults()
        {
        }

        // Predecessor access
        public Conversation Conversation
        {
            get { return _conversation.Fact; }
        }
        public User Sender
        {
            get { return _sender.Fact; }
        }

        // Field access
        public string Body
        {
            get { return _body; }
        }

        // Query result access
    }
    
}
