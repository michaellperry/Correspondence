﻿using System.Linq;
using Correspondence.WP7.Model;
using Correspondence.WP7.ViewModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UpdateControls.Correspondence;
using UpdateControls.Correspondence.Memory;
using UpdateControls.Correspondence.Strategy;

namespace $safeprojectname$.Tests
{
    [TestClass]
    public class UserViewModelTest
    {
        private Community _bobCommunity;
        private Community _aliceCommunity;
        private User _bob;
        private User _alice;
        private UserViewModel _bobViewModel;
        private UserViewModel _aliceViewModel;

        [TestInitialize]
        public void Initialize()
        {
            ICommunicationStrategy sharedCommunicationStrategy = new MemoryCommunicationStrategy();
            _bobCommunity = new Community(new MemoryStorageStrategy())
                .AddCommunicationStrategy(sharedCommunicationStrategy)
                .RegisterAssembly(typeof(User))
                .Subscribe(() => _bob);
            _aliceCommunity = new Community(new MemoryStorageStrategy())
                .AddCommunicationStrategy(sharedCommunicationStrategy)
                .RegisterAssembly(typeof(User))
                .Subscribe(() => _alice);
            _bob = _bobCommunity.AddFact(new User("Bob"));
            _alice = _aliceCommunity.AddFact(new User("Alice"));

            _bobViewModel = new UserViewModel(_bob, new UserNavigationModel());
            _aliceViewModel = new UserViewModel(_alice, new UserNavigationModel());
        }

        [TestMethod]
        public void WhenBobAddsConversation_ThenAliceSeesConversation()
        {
            _bobViewModel.OtherUserName = "Alice";
            _bobViewModel.BeginConversation.Execute(null);

            Synchronize();

            Assert.AreEqual("Bob", _aliceViewModel.Conversations.Single().OtherUserName);
        }

        private void Synchronize()
        {
            while (_bobCommunity.Synchronize() || _aliceCommunity.Synchronize()) ;
        }
    }
}
