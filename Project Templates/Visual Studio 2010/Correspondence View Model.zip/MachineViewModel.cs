﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using UpdateControls.XAML;

namespace $safeprojectname$
{
	public class MachineViewModel
	{
		private Machine _machine;
		private MachineNavigationModel _navigation;

		public MachineViewModel(
			Machine machine,
			MachineNavigationModel navigation)
		{
			_machine = machine;
			_navigation = navigation;
		}
	}
}
