﻿using System;
using UpdateControls;

namespace $safeprojectname$
{
	public class MachineNavigationModel
	{
	}
}
