﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using UpdateControls.XAML;

namespace $safeprojectname$
{
    public class ViewModel1
    {
		private Machine _machine;
		private NavigationModel1 _navigation;

		public ViewModel1(
			Machine machine,
			NavigationModel1 navigation)
		{
			_machine = machine;
			_navigation = navigation;
		}
    }
}
