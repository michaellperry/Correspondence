﻿using System;
using UpdateControls;

namespace $safeprojectname$
{
	public class NavigationModel1
	{
	}
}
