﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UpdateControls.Correspondence;
using UpdateControls.Correspondence.Memory;

namespace $safeprojectname$.ModelTests
{
	[TestClass]
	public class MachineModelTest
	{
		private Community _community;

		[TestInitialize()]
		public void Initialize()
		{
			_community = new Community(new MemoryStorageStrategy())
				.RegisterAssembly(typeof(Machine));
		}

		[TestMethod]
		public void Test1()
		{
			Machine thisMachine = _community.AddFact(new Machine());

			Assert.Fail();
		}
	}
}
