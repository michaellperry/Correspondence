﻿using System.Collections.Generic;
using System.Linq;
using UpdateControls.Correspondence;
using UpdateControls.Correspondence.Mementos;
using System;

namespace $safeprojectname$
{
    [CorrespondenceType]
    public partial class Machine : CorrespondenceFact
    {
        // Roles

        // Queries
        public static Query QueryActiveLogOns = new Query()
            .JoinSuccessors(LogOn.RoleMachine, Condition.WhereIsEmpty(LogOn.QueryIsActive)
            )
            ;

        // Predicates

        // Predecessors

        // Unique
        [CorrespondenceField]
        private Guid _unique;

        // Fields

        // Results
        private Result<LogOn> _activeLogOns;

        // Business constructor
        public Machine(
            )
        {
            _unique = Guid.NewGuid();
            InitializeResults();
        }

        // Hydration constructor
        public Machine(FactMemento memento)
        {
            InitializeResults();
        }

        // Result initializer
        private void InitializeResults()
        {
            _activeLogOns = new Result<LogOn>(this, QueryActiveLogOns);
        }

        // Predecessor access

        // Field access

        // Query result access
        public IEnumerable<LogOn> ActiveLogOns
        {
            get { return _activeLogOns; }
        }
    }
    
    [CorrespondenceType]
    public partial class User : CorrespondenceFact
    {
        // Roles

        // Queries
        public static Query QueryConversations = new Query()
            .JoinSuccessors(Conversation.RoleParticipants)
            ;

        // Predicates

        // Predecessors

        // Fields
        [CorrespondenceField]
        private string _userName;

        // Results
        private Result<Conversation> _conversations;

        // Business constructor
        public User(
            string userName
            )
        {
            InitializeResults();
            _userName = userName;
        }

        // Hydration constructor
        public User(FactMemento memento)
        {
            InitializeResults();
        }

        // Result initializer
        private void InitializeResults()
        {
            _conversations = new Result<Conversation>(this, QueryConversations);
        }

        // Predecessor access

        // Field access
        public string UserName
        {
            get { return _userName; }
        }

        // Query result access
        public IEnumerable<Conversation> Conversations
        {
            get { return _conversations; }
        }
    }
    
    [CorrespondenceType]
    public partial class LogOn : CorrespondenceFact
    {
        // Roles
        public static Role<User> RoleUser = new Role<User>("user");
        public static Role<Machine> RoleMachine = new Role<Machine>("machine");

        // Queries
        public static Query QueryIsActive = new Query()
            .JoinSuccessors(LogOff.RoleLogOn)
            ;

        // Predicates
        public static Condition IsActive = Condition.WhereIsEmpty(QueryIsActive);

        // Predecessors
        private PredecessorObj<User> _user;
        private PredecessorObj<Machine> _machine;

        // Unique
        [CorrespondenceField]
        private Guid _unique;

        // Fields

        // Results

        // Business constructor
        public LogOn(
            User user
            ,Machine machine
            )
        {
            _unique = Guid.NewGuid();
            InitializeResults();
            _user = new PredecessorObj<User>(this, RoleUser, user);
            _machine = new PredecessorObj<Machine>(this, RoleMachine, machine);
        }

        // Hydration constructor
        public LogOn(FactMemento memento)
        {
            InitializeResults();
            _user = new PredecessorObj<User>(this, RoleUser, memento);
            _machine = new PredecessorObj<Machine>(this, RoleMachine, memento);
        }

        // Result initializer
        private void InitializeResults()
        {
        }

        // Predecessor access
        public User User
        {
            get { return _user.Fact; }
        }
        public Machine Machine
        {
            get { return _machine.Fact; }
        }

        // Field access

        // Query result access
    }
    
    [CorrespondenceType]
    public partial class LogOff : CorrespondenceFact
    {
        // Roles
        public static Role<LogOn> RoleLogOn = new Role<LogOn>("logOn");

        // Queries

        // Predicates

        // Predecessors
        private PredecessorObj<LogOn> _logOn;

        // Fields

        // Results

        // Business constructor
        public LogOff(
            LogOn logOn
            )
        {
            InitializeResults();
            _logOn = new PredecessorObj<LogOn>(this, RoleLogOn, logOn);
        }

        // Hydration constructor
        public LogOff(FactMemento memento)
        {
            InitializeResults();
            _logOn = new PredecessorObj<LogOn>(this, RoleLogOn, memento);
        }

        // Result initializer
        private void InitializeResults()
        {
        }

        // Predecessor access
        public LogOn LogOn
        {
            get { return _logOn.Fact; }
        }

        // Field access

        // Query result access
    }
    
    [CorrespondenceType]
    public partial class Conversation : CorrespondenceFact
    {
        // Roles
        public static Role<User> RoleParticipants = new Role<User>("participants", RoleRelationship.Pivot);

        // Queries
        public static Query QueryMessages = new Query()
            .JoinSuccessors(Message.RoleConversation)
            ;

        // Predicates

        // Predecessors
        private PredecessorList<User> _participants;

        // Fields

        // Results
        private Result<Message> _messages;

        // Business constructor
        public Conversation(
            IEnumerable<User> participants
            )
        {
            InitializeResults();
            _participants = new PredecessorList<User>(this, RoleParticipants, participants);
        }

        // Hydration constructor
        public Conversation(FactMemento memento)
        {
            InitializeResults();
            _participants = new PredecessorList<User>(this, RoleParticipants, memento);
        }

        // Result initializer
        private void InitializeResults()
        {
            _messages = new Result<Message>(this, QueryMessages);
        }

        // Predecessor access
        public IEnumerable<User> Participants
        {
            get { return _participants; }
        }
     
        // Field access

        // Query result access
        public IEnumerable<Message> Messages
        {
            get { return _messages; }
        }
    }
    
    [CorrespondenceType]
    public partial class Message : CorrespondenceFact
    {
        // Roles
        public static Role<Conversation> RoleConversation = new Role<Conversation>("conversation");
        public static Role<User> RoleSender = new Role<User>("sender");

        // Queries

        // Predicates

        // Predecessors
        private PredecessorObj<Conversation> _conversation;
        private PredecessorObj<User> _sender;

        // Fields
        [CorrespondenceField]
        private string _body;

        // Results

        // Business constructor
        public Message(
            Conversation conversation
            ,User sender
            ,string body
            )
        {
            InitializeResults();
            _conversation = new PredecessorObj<Conversation>(this, RoleConversation, conversation);
            _sender = new PredecessorObj<User>(this, RoleSender, sender);
            _body = body;
        }

        // Hydration constructor
        public Message(FactMemento memento)
        {
            InitializeResults();
            _conversation = new PredecessorObj<Conversation>(this, RoleConversation, memento);
            _sender = new PredecessorObj<User>(this, RoleSender, memento);
        }

        // Result initializer
        private void InitializeResults()
        {
        }

        // Predecessor access
        public Conversation Conversation
        {
            get { return _conversation.Fact; }
        }
        public User Sender
        {
            get { return _sender.Fact; }
        }

        // Field access
        public string Body
        {
            get { return _body; }
        }

        // Query result access
    }
    
}
